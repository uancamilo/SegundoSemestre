public class Main {
    public static void main(String[] args) {
        Persona persona = new Persona("Juan", "Hombre");

        Ciudad ciudad = new Ciudad(1, 2);

        System.out.println(persona);
        System.out.println(ciudad);
    }
}
